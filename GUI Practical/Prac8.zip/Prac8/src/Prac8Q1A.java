
import javax.swing.*;

public class Prac8Q1A extends JFrame {
    
    private JButton jbtn;
    
    public Prac8Q1A() {
        ImageIcon grapeIcon = new ImageIcon(getClass().getResource("/images/grapes.gif"));
        jbtn = new JButton("Grapes", grapeIcon);
        add(jbtn);
        
        jbtn.setHorizontalAlignment(SwingConstants.RIGHT);
        jbtn.setVerticalAlignment(SwingConstants.TOP);
        jbtn.setHorizontalTextPosition(SwingConstants.LEFT);
        jbtn.setVerticalTextPosition(SwingConstants.BOTTOM);
        
        setTitle("Testing Alignment");
        setLocationRelativeTo(null);
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
    
    public static void main(String[] args) {
        new Prac8Q1A();
    }
}
