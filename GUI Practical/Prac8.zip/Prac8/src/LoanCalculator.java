
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class LoanCalculator extends JFrame {

    private JTextField jtfInterestRate = new JTextField();
    private JTextField jtfNoOfYears = new JTextField();
    private JTextField jtfLoanAmount = new JTextField();
    private JTextField jtfMPayment = new JTextField();
    private JTextField jtfTPayment = new JTextField();
    private JButton jbtnCompute = new JButton("Compute Payment");

    public LoanCalculator() {
        JPanel jpLoan = new JPanel(new GridLayout(5, 2));
        jpLoan.add(new JLabel("Annual Interest Rate"));
        jpLoan.add(jtfInterestRate);
        jpLoan.add(new JLabel("Number of Years"));
        jpLoan.add(jtfNoOfYears);
        jpLoan.add(new JLabel("Loan Amount"));
        jpLoan.add(jtfLoanAmount);
        jpLoan.add(new JLabel("Monthly Payment"));
        jpLoan.add(jtfMPayment);
        jpLoan.add(new JLabel("Total Payment"));
        jpLoan.add(jtfTPayment);
        jpLoan.setBorder(new TitledBorder("Enter Loan amount, intereset rate, and year"));

        jtfMPayment.setEditable(false);
        jtfTPayment.setEditable(false);

        JPanel jpRIGHT = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        jpRIGHT.add(jbtnCompute);

        add(jpLoan, BorderLayout.CENTER);
        add(jpRIGHT, BorderLayout.SOUTH);

        jbtnCompute.addActionListener(new ComputeLoanClass());

        setTitle("Loan Calculator");
        setLocationRelativeTo(null);
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    private class ComputeLoanClass implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                double interestRate = Double.parseDouble(jtfInterestRate.getText());
                int noOfYears = Integer.parseInt(jtfNoOfYears.getText());
                double loanAmount = Double.parseDouble(jtfLoanAmount.getText());

                Loan loan = new Loan(interestRate, noOfYears, loanAmount);

                jtfMPayment.setText(String.format("%.2f", loan.getMonthlyPayment()));
                jtfTPayment.setText(String.format("%.2f", loan.getTotalPayment()));
            } catch (NumberFormatException ex) {
                jtfMPayment.setText("Number is required");
                jtfTPayment.setText("Number is required");
            }
        }
    }

    public static void main(String[] args) {
        new LoanCalculator();
    }
}
