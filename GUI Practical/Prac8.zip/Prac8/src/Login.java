
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Login extends JFrame {

    private JTextField jtfUserName = new JTextField();
    private JPasswordField jpfPassword = new JPasswordField();
    private JButton jbtnLogin = new JButton("Login");
    private JButton jbtnReset = new JButton("Reset");

    public Login() {
        JPanel jplogin = new JPanel(new GridLayout(3, 2));
        jplogin.add(new JLabel("User name"));
        jplogin.add(jtfUserName);
        jplogin.add(new JLabel("Password"));
        jplogin.add(jpfPassword);
        jplogin.add(new JLabel(""));
        jpfPassword.setEchoChar('*');

        JPanel jpButton = new JPanel(new GridLayout(1, 2));
        jpButton.add(jbtnLogin);
        jpButton.add(jbtnReset);
        jplogin.add(jpButton);
        add(jplogin);

        jbtnLogin.addActionListener(new LoginListener());
        jbtnReset.addActionListener(new ResetListener());

        setTitle("Login");
        setLocationRelativeTo(null);
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);

    }

    private class LoginListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            String username = jtfUserName.getText();
            String password = new String(jpfPassword.getPassword());

            if (username.equals("zixuan") && password.equals("abc123")) {
                JOptionPane.showMessageDialog(null,
                        "Login Successful"
                );

                // Invoke loan calculator
                LoanCalculator loanCalculator = new LoanCalculator();
                //set the login frame to invisible
                setVisible(false);
            } else {
                JOptionPane.showMessageDialog(null,
                        "Unsuccessful Login"
                );
            }
        }
    }

    private class ResetListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            jtfUserName.setText("");
            jpfPassword.setText("");
        }
    }

    public static void main(String[] args) {
        new Login();
    }
}
