
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;

public class CheckOutSystemJList extends JFrame implements ItemListener {

    private JTextField jtfName = new JTextField();
    private JTextField jtfID = new JTextField();

    private JComboBox jcb;

    private JList jl;
    private String[] swOptions = {"Windows 8", "Windows 10", "Visual Studio 2015", "SQL Server"};

    private JButton jbtnConfirm = new JButton("Confirm");
    private JButton jbtnClear = new JButton("Clear");
    private JButton jbtnExit = new JButton("Exit");

    @Override
    public void itemStateChanged(ItemEvent e) {
        if (e.getSource() == jcb) {
            String s = (String) e.getItem();
            JOptionPane.showMessageDialog(null, s);
        }
    }

    public CheckOutSystemJList() {

        JPanel jpNID = new JPanel(new GridLayout(2, 2));
        jpNID.add(new JLabel("Name"));
        jpNID.add(jtfName);
        jpNID.add(new JLabel("ID"));
        jpNID.add(jtfID);

        add(jpNID, BorderLayout.NORTH);

        // JCombobox
        JPanel jpProg = new JPanel();
        jcb = new JComboBox(new Object[]{"DIA2", "DIB2", "DIT2", "DST2"});
        jpProg.add(jcb);
        add(jpProg, BorderLayout.WEST);

        // JList
        JPanel jpSw = new JPanel();
        jl = new JList(swOptions);
        jpSw.add(jl);
        add(jpSw, BorderLayout.EAST);

        JPanel jpBtnGrps = new JPanel();
        jpBtnGrps.add(jbtnConfirm);
        jpBtnGrps.add(jbtnClear);
        jpBtnGrps.add(jbtnExit);
        add(jpBtnGrps, BorderLayout.SOUTH);

        jbtnConfirm.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                StringBuilder sb = new StringBuilder();

                String name = jtfName.getText();
                String id = jtfID.getText();

                // get the JList multiple items
                String sw = "";
                java.util.List selectedItems = jl.getSelectedValuesList();
                for (int i = 0; i < selectedItems.size(); i++) {
                    sw += (String) selectedItems.get(i) + "\n";
                }

                int optionY;
                optionY = JOptionPane.showConfirmDialog(null, "Name: " + name + "\nID: " + id
                        + "\nProgramme: " + jcb.getSelectedItem() + "\nSoftware Selected:\n" + sw
                        + "\n\nIs this information correct?", "Check Information", JOptionPane.YES_NO_OPTION);

                if (optionY == JOptionPane.YES_OPTION) {
                    JOptionPane.showMessageDialog(null, "Thank you");
                }
            }
        });

        jbtnClear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                jtfName.setText("");
                jtfID.setText("");
            }
        });

        jbtnExit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });

        this.setSize(400, 200);
        this.setTitle("Check Out System");
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public static void main(String[] args) {
        new CheckOutSystemJList();
    }

}
