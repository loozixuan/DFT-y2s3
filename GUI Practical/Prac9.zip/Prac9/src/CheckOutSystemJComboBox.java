
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class CheckOutSystemJComboBox extends JFrame implements ItemListener {

    private JTextField jtfName = new JTextField();
    private JTextField jtfID = new JTextField();

    private JComboBox jcb;
    private JCheckBox[] jchks;
    private String[] swOptions = {"Windows 8", "Windows 10", "Visual Studio 2015", "SQL Server"};

    private JButton jbtnConfirm = new JButton("Confirm");
    private JButton jbtnClear = new JButton("Clear");
    private JButton jbtnExit = new JButton("Exit");

    @Override
    public void itemStateChanged(ItemEvent e) {
        if (e.getSource() == jcb) {
            String s = (String) e.getItem();
            JOptionPane.showMessageDialog(null, s);
        }
    }

    public CheckOutSystemJComboBox() {

        jchks = new JCheckBox[swOptions.length];

        JPanel jpNID = new JPanel(new GridLayout(2, 2));
        jpNID.add(new JLabel("Name"));
        jpNID.add(jtfName);
        jpNID.add(new JLabel("ID"));
        jpNID.add(jtfID);

        add(jpNID, BorderLayout.NORTH);

        JPanel jpProg = new JPanel();
        jcb = new JComboBox(new Object[]{"DIA2", "DIB2", "DIT2", "DST2"});
        jpProg.add(jcb);
        add(jpProg, BorderLayout.WEST);

        JPanel jpSw = new JPanel(new GridLayout(5, 1));
        for (int i = 0; i < swOptions.length; i++) {
            jchks[i] = new JCheckBox(swOptions[i]);
            jpSw.add(jchks[i]);
        }
        add(jpSw, BorderLayout.EAST);

        JPanel jpBtnGrps = new JPanel();
        jpBtnGrps.add(jbtnConfirm);
        jpBtnGrps.add(jbtnClear);
        jpBtnGrps.add(jbtnExit);
        add(jpBtnGrps, BorderLayout.SOUTH);

        jbtnConfirm.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                StringBuilder sb = new StringBuilder();
                for (JCheckBox jchk : jchks) {

                    if (jchk.isSelected()) {
                        sb.append(jchk.getText() + "\n");
                    }

                }

                String name = jtfName.getText();
                String id = jtfID.getText();

                int optionY;
                optionY = JOptionPane.showConfirmDialog(null, "Name: " + name + "\nID: " + id
                        + "\nProgramme: " + jcb.getSelectedItem() + "\nSoftware Selected:\n" + sb.toString()
                        + "\n\nIs this information correct?", "Check Information", JOptionPane.YES_NO_OPTION);

                if (optionY == JOptionPane.YES_OPTION) {
                    JOptionPane.showMessageDialog(null, "Thank you");
                }
            }
        });

        jbtnClear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                jtfName.setText("");
                jtfID.setText("");
                for (JCheckBox jchk : jchks) {
                    jchk.setSelected(false);
                }
            }
        });

        jbtnExit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });

        this.setSize(400, 350);
        this.setTitle("Check Out System");
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public static void main(String[] args) {
        new CheckOutSystemJComboBox();
    }

}
