
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class CheckOutSystem extends JFrame {

    private JTextField jtfName = new JTextField();
    private JTextField jtfID = new JTextField();

    private ButtonGroup buttonGroup;
    private JRadioButton[] jrBtns;
    private String[] progOptions = {"DIA2", "DIB2", "DIT2", "DST2"};

    private JCheckBox[] jchks;
    private String[] swOptions = {"Windows 8", "Windows 10", "Visual Studio 2015", "SQL Server"};

    private JButton jbtnConfirm = new JButton("Confirm");
    private JButton jbtnClear = new JButton("Clear");
    private JButton jbtnExit = new JButton("Exit");

    private String option;

    public CheckOutSystem() {

        jchks = new JCheckBox[swOptions.length];

        JPanel jpNID = new JPanel(new GridLayout(2, 2));
        jpNID.add(new JLabel("Name"));
        jpNID.add(jtfName);
        jpNID.add(new JLabel("ID"));
        jpNID.add(jtfID);

        add(jpNID, BorderLayout.NORTH);

        // Radio Button
        JPanel jpProg = new JPanel(new GridLayout(5, 1));
        buttonGroup = new ButtonGroup();
        jrBtns = new JRadioButton[progOptions.length];
        for (int i = 0; i < progOptions.length; i++) {
            jrBtns[i] = new JRadioButton(progOptions[i]);
            buttonGroup.add(jrBtns[i]);
            jpProg.add(jrBtns[i]);
            // Get the selected data from radio button
            jrBtns[i].addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    option = e.getActionCommand();
                }
            });
        }
        add(jpProg, BorderLayout.WEST);

        // JCheckbox
        JPanel jpSw = new JPanel(new GridLayout(5, 1));
        for (int i = 0; i < swOptions.length; i++) {
            jchks[i] = new JCheckBox(swOptions[i]);
            jpSw.add(jchks[i]);
        }
        add(jpSw, BorderLayout.EAST);

        JPanel jpBtnGrps = new JPanel();
        jpBtnGrps.add(jbtnConfirm);
        jpBtnGrps.add(jbtnClear);
        jpBtnGrps.add(jbtnExit);
        add(jpBtnGrps, BorderLayout.SOUTH);

        // Listener to get the respective data
        jbtnConfirm.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get the selected checkbox value(s)
                StringBuilder sb = new StringBuilder();
                for (JCheckBox jchk : jchks) {
                    if (jchk.isSelected()) {
                        sb.append(jchk.getText() + "\n");
                    }
                }

                String name = jtfName.getText();
                String id = jtfID.getText();

                int optionY;
                optionY = JOptionPane.showConfirmDialog(null, "Name: " + name + "\nID: " + id
                        + "\nProgramme: " + option + "\nSoftware Selected:\n" + sb.toString()
                        + "\n\nIs this information correct?", "Check Information", JOptionPane.YES_NO_OPTION);

                if (optionY == JOptionPane.YES_OPTION) {
                    JOptionPane.showMessageDialog(null, "Thank you");
                }
            }
        });

        jbtnClear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                jtfName.setText("");
                jtfID.setText("");
                buttonGroup.clearSelection();
                for (JCheckBox jchk : jchks) {
                    jchk.setSelected(false);
                }
            }
        });

        jbtnExit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        this.setSize(400, 350);
        this.setTitle("Check Out System");
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public static void main(String[] args) {
        new CheckOutSystem();
    }
}
