
import java.awt.GridLayout;
import javax.swing.*;

public class SoftwareCheckOutPanel extends JPanel {

    public SoftwareCheckOutPanel(SoftwareCheckOut s) {

        setLayout(new GridLayout(10, 1));
        add(new JLabel("Software Checkout Summary"));
        add(new JLabel("Student Name: " + s.getName()));
        add(new JLabel("Student id: " + s.getId()));
        add(new JLabel("Programme: " + s.getProgramme()));
        add(new JLabel("Software List:"));

        java.util.List softwareList = s.getSoftwareList();
        for (int i = 0; i < softwareList.size(); i++) {
            add(new JLabel("- " + (i + 1) + ". " + (String) softwareList.get(i)));
        }
    }

}
