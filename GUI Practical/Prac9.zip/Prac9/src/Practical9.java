
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author shawn
 */
public class Practical9 extends JFrame {

    private ButtonGroup buttonGroup;
    private JRadioButton[] jrBtns;
    private String[] options = {"A", "B", "C"};

    private JCheckBox[] jchks;

    public Practical9() {

        this.setLayout(new GridLayout(options.length + 1, 1));
        jrBtns = new JRadioButton[options.length];
        jchks = new JCheckBox[options.length];
        buttonGroup = new ButtonGroup();
        JButton jbtnShow = new JButton("Show");
        for (int i = 0; i < options.length; i++) {
//            jrBtns[i] = new JRadioButton(options[i]);
//            buttonGroup.add(jrBtns[i]);
//            add(jrBtns[i]);
//            jrBtns[i].addActionListener(new ActionListener() {
//                @Override
//                public void actionPerformed(ActionEvent e) {
//                    JOptionPane.showMessageDialog(null, e.getActionCommand());
//                }
//            });
            jchks[i] = new JCheckBox(options[i]);
            add(jchks[i]);
        }
        add(jbtnShow);
        jbtnShow.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                StringBuilder sb = new StringBuilder();
                for (JCheckBox jchk : jchks) {

                    if (jchk.isSelected()) {
                        sb.append(jchk.getText() + "\n");
                    }

                }
                JOptionPane.showMessageDialog(null, sb.toString());
            }
        });

        this.setSize(400, 400);
        this.setTitle("Practical 9");
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        pack();
        setVisible(true);
    }

    public static void main(String[] args) {
        new Practical9();
    }
}
