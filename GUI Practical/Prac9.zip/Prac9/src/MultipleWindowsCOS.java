
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;

public class MultipleWindowsCOS extends JFrame {

    private JTextField jtfName = new JTextField();
    private JTextField jtfID = new JTextField();

    private ButtonGroup buttonGroup;
    private JRadioButton[] jrBtns;
    private String[] progOptions = {"DIA2", "DIB2", "DIT2", "DST2"};

    private JCheckBox[] jchks;
    private String[] swOptions = {"Windows 8", "Windows 10", "Visual Studio 2015", "SQL Server"};

    private JButton jbtnConfirm = new JButton("Confirm");
    private JButton jbtnClear = new JButton("Clear");
    private JButton jbtnExit = new JButton("Exit");

    private String option;

    private JFrame softwareCheckOutFrame = new JFrame();

    public MultipleWindowsCOS() {

        jchks = new JCheckBox[swOptions.length];

        JPanel jpNID = new JPanel(new GridLayout(2, 2));
        jpNID.add(new JLabel("Name"));
        jpNID.add(jtfName);
        jpNID.add(new JLabel("ID"));
        jpNID.add(jtfID);

        add(jpNID, BorderLayout.NORTH);

        JPanel jpProg = new JPanel(new GridLayout(5, 1));
        buttonGroup = new ButtonGroup();
        jrBtns = new JRadioButton[progOptions.length];
        for (int i = 0; i < progOptions.length; i++) {
            jrBtns[i] = new JRadioButton(progOptions[i]);
            buttonGroup.add(jrBtns[i]);
            jpProg.add(jrBtns[i]);
            jrBtns[i].addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    option = e.getActionCommand();
                }
            });
        }
        add(jpProg, BorderLayout.WEST);

        JPanel jpSw = new JPanel(new GridLayout(5, 1));
        for (int i = 0; i < swOptions.length; i++) {
            jchks[i] = new JCheckBox(swOptions[i]);
            jpSw.add(jchks[i]);
        }
        add(jpSw, BorderLayout.EAST);

        JPanel jpBtnGrps = new JPanel();
        jpBtnGrps.add(jbtnConfirm);
        jpBtnGrps.add(jbtnClear);
        jpBtnGrps.add(jbtnExit);
        add(jpBtnGrps, BorderLayout.SOUTH);

        jbtnConfirm.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ArrayList<String> swList = new ArrayList<String>();
                String name = jtfName.getText();
                String id = jtfID.getText();
                String programme = option;

                for (JCheckBox jchk : jchks) {
                    if (jchk.isSelected()) {
                        swList.add(jchk.getText() + "\n");
                    }
                }

                SoftwareCheckOutPanel softwareCheckOutPanel = new SoftwareCheckOutPanel(new SoftwareCheckOut(name, id, programme, swList));
                softwareCheckOutFrame.add(softwareCheckOutPanel, BorderLayout.CENTER);
                softwareCheckOutFrame.setSize(300, 300);
                softwareCheckOutFrame.setVisible(true);
                softwareCheckOutFrame.setLocationRelativeTo(null);
                softwareCheckOutFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            }
        });

        jbtnClear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                jtfName.setText("");
                jtfID.setText("");
                buttonGroup.clearSelection();
                for (JCheckBox jchk : jchks) {
                    jchk.setSelected(false);
                }
            }
        });

        jbtnExit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });

        this.setSize(500, 350);
        this.setTitle("MultipleWindows Check Out System");
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public static void main(String[] args) {
        new MultipleWindowsCOS();
    }
}
