package controller;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import da.ProgrammeDA;
import da.StudentDA;
import domain.Programme;
import domain.Student;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author zixua
 */
public class StudentServlet extends HttpServlet {

    private StudentDA studDA;
    private ProgrammeDA progDA;

    @Override
    public void init() throws ServletException {
        studDA = new StudentDA();
        progDA = new ProgrammeDA();
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        String id = request.getParameter("id");
        String ic = request.getParameter("ic");
        String name = request.getParameter("name");

        char level = request.getParameter("level").charAt(0);
        String code = request.getParameter("progCode");
        int year = Integer.parseInt(request.getParameter("yr"));

        try (PrintWriter out = response.getWriter()) {
            out.println("Student ID: <b>" + id + "</b> <br />");
            out.println("IC Number: <b>" + ic + "</b> <br />");
            out.println("Name: <b>" + name + "</b> <br />");
            out.println("Level: <b>" + level + "</b> <br />");
            out.println("Programme code: <b>" + code + "</b> <br />");
            out.println("Year: <b>" + year + "</b> <br />");

            Cookie nameCk = new Cookie("name", name);
            response.addCookie(nameCk);

            out.println("<a href='NameServlet'>Click Here" + "</a>");
        }

    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String id = request.getParameter("id");
        String ic = request.getParameter("ic");
        String name = request.getParameter("name");

        char level = request.getParameter("level").charAt(0);
        String code = request.getParameter("progCode");
        int year = Integer.parseInt(request.getParameter("yr"));

        try (PrintWriter out = response.getWriter()) {
            if (id == null || ("").equals(id)) {
                out.println("ID value is required");
            } else {
                try {
                    Programme p = progDA.getRecord(code);
                    Student stu = new Student(id, ic, name, level, p, year);
                    studDA.addRecord(stu);
                } catch (SQLException ex) {
                    out.println(ex.getMessage());
                }
                out.println("Student" + name + "has been added");
            }
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
