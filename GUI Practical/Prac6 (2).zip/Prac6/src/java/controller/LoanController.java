/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import domain.Loan;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author zixua
 */
@WebServlet(name = "LoanController", urlPatterns = ("/LoanController"))

public class LoanController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        String amountStr = request.getParameter("amount");
        String rateStr = request.getParameter("rate");
        String durationStr = request.getParameter("duration");

        try (PrintWriter out = response.getWriter()) {
            if (amountStr.length() == 0 || rateStr.length() == 0 || durationStr.length() == 0) {
                out.println("<font color=red>Loan amount, annual interest rate and duration of years are null</font>");
            } else {
                double amount = Double.parseDouble(amountStr);
                double rate = Double.parseDouble(rateStr);
                int duration = Integer.parseInt(durationStr);

                Loan loan = new Loan(rate, duration, amount);

                HttpSession httpSession = request.getSession();
                httpSession.setAttribute("loan", loan);

                out.println("You entered the following information:");
                out.println("<p>Loan Amount: RM " + String.format("%.2f", amount));
                out.println("<br />Annual Interest Rate: " + String.format("%.2f", rate));
                out.println("<br />Number of Years: " + duration);

                out.println("<p><form method=\"post\" action=Loan>");
                out.println("<p><input type=\"submit\" value=\"confirm\" >");
                out.println("</form>");
            }
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        try (PrintWriter out = response.getWriter()) {

            Loan loan = (Loan) (request.getSession().getAttribute("loan"));
            out.println("<p>Loan Amount:  RM" + String.format("%.2f", loan.getLoanAmount()));
            out.println("<br />Annual Interest Rate: " + String.format("%.2f", loan.getAnnualInterestRate()));
            out.println("<br />Number of Years: " + loan.getNumberOfYears());
            out.println("<br />Monthly Payment: RM<b>" + String.format("%.2f", loan.getMonthlyPayment()));
            out.println("<br />Total Payment: RM<b>" + String.format("%.2f", loan.getTotalPayment()));
        }

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
